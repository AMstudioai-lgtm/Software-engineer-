# data-manager

Skill multi-agents pour concevoir et auditer des systèmes de données. Il transforme les concepts de *Designing Data-Intensive Applications* (Martin Kleppmann, 2017) en procédures d'analyse, de décision et de validation.

## Installation via npm

Prérequis : Node.js 18 ou supérieur. Aucun package npm tiers n'est nécessaire.

Installation dans le projet courant :

```bash
npx -y data-manager-agent-skill init --agent codex
```

Choisissez l'agent cible : `codex`, `gemini-cli`, `antigravity`, `claude-code`, `opencode`, `cursor` ou `adk-python`.

```bash
# Installer dans un projet spécifique
npx -y data-manager-agent-skill init --agent adk-python --project ./mon-agent-adk

# Installer pour tous les agents pris en charge dans le projet
npx -y data-manager-agent-skill init --agent all --project .

# Installation dans le répertoire utilisateur (global)
npx -y data-manager-agent-skill init --agent claude-code --global

# Simuler sans modifier de fichiers
npx -y data-manager-agent-skill init --agent opencode --dry-run

# Lister les destinations
npx -y data-manager-agent-skill list
```

L'installateur refuse d'écraser une installation existante. Examinez-la avant de relancer avec `--force`.

Vous pouvez aussi installer le paquet puis appeler la commande :

```bash
npm install --save-dev data-manager-agent-skill
npx data-manager-skill init --agent codex
```

## Contenu

- `SKILL.md`: instructions principales et contrat de sortie.
- `references/`: fiches de connaissances, résumées et reformulées.
- `agents/`: rôles et contrats de délégation multi-agents.
- `templates/`: brief d'architecture, ADR et profil de charge.
- `scripts/`: installation Python historique, validation et contrôle de complétude d'un brief JSON.
- `adk-example/`: exemple d'intégration avec Google ADK Python.
- `READING_AUDIT.md`: méthode de lecture et limites de l'audit.

## Google ADK Python

Pour un projet ADK existant, installez le skill à la racine du package agent :

```bash
npx -y data-manager-agent-skill init --agent adk-python --project ./mon-agent-adk
```

L'exemple autonome est dans `adk-example/` :

```bash
cd adk-example
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export GOOGLE_API_KEY="votre-cle-api"
adk run data_manager_demo
```

L'API Skills d'ADK est expérimentale. Vérifiez la version de `google-adk` et la documentation avant une adoption en production.

## Vérification du paquet

```bash
npx data-manager-skill validate
python scripts/validate_skill.py
python -m unittest discover -s tests -v
```

## Limites

Les scripts contrôlent la structure et la complétude des livrables. Ils ne prouvent ni la correction d'une architecture, ni les performances d'une base, ni la conformité réglementaire. La revue humaine reste obligatoire pour les migrations et les opérations de production.
