# ADK Python example: Data Manager team

This folder shows one coordinator delegating work to specialist agents. Each specialist receives the same `data-manager` SkillToolset. Delegation is a decision of the coordinator, not an instruction to run every specialist for every request.

## 1. Requirements

- Python 3.10 or newer, according to the ADK version you install.
- A Google AI Studio API key or a configured Vertex AI environment.
- `google-adk` version 1.25.0 or newer for the documented experimental Skills API.

## 2. Install

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export GOOGLE_API_KEY="your-key"
```

On Windows, activate with `.venv\\Scripts\\activate`.

The skill is already included under `data_manager_demo/skills/data-manager/` so the path works after extraction.

## 3. Run

From this `adk-example` directory:

```bash
adk run data_manager_demo
```

For the web UI:

```bash
adk web --port 8000
```

Then select `data_manager_demo` in the local ADK interface.

## 4. Team design

- Coordinator: frames the problem and delegates.
- Data Architect: system-level tradeoffs.
- Data Modeler: entities, relationships, invariants.
- Storage Engineer: access patterns, storage and indexes.
- Distributed Reviewer: replication, partitioning and failure semantics.
- Pipeline Engineer: batch, streaming and derived views.
- Reliability Auditor: challenges the result and returns `APPROVE`, `REVISE` or `BLOCK`.

## 5. Important

This is a code example, not a production deployment. The runtime API is experimental and may change. The Python files are syntax-checked in this package, but the ADK dependencies, model authentication, SkillToolset runtime and actual agent conversations were not executed here. Verify the current ADK documentation and run a local smoke test before using it with company data.
