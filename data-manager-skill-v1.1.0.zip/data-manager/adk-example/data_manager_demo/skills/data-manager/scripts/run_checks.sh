#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
python3 "$ROOT/scripts/validate_skill.py"
python3 -m unittest discover -s "$ROOT/tests" -v
python3 "$ROOT/scripts/check_secrets.py"
python3 -m compileall -q "$ROOT/scripts" "$ROOT/adk-example"
echo "All local checks passed. ADK runtime/API calls were not executed."
