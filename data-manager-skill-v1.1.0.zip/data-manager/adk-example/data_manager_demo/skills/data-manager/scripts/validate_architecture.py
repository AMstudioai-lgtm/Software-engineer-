#!/usr/bin/env python3
"""Completeness checks for a data architecture brief stored as JSON.

This is a checklist, not a proof of correctness, security or performance.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


def is_present(value: Any) -> bool:
    return value is not None and value != "" and value != [] and value != {}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("brief", type=Path, help="Path to an architecture brief JSON file")
    args = parser.parse_args()

    try:
        data = json.loads(args.brief.read_text(encoding="utf-8"))
    except FileNotFoundError:
        print(f"ERROR: file not found: {args.brief}", file=sys.stderr)
        return 2
    except json.JSONDecodeError as exc:
        print(f"ERROR: invalid JSON at line {exc.lineno}, column {exc.colno}: {exc.msg}", file=sys.stderr)
        return 2

    if not isinstance(data, dict):
        print("ERROR: root JSON value must be an object", file=sys.stderr)
        return 2

    errors: list[str] = []
    warnings: list[str] = []
    required = ["system_name", "requirements", "workload", "data_model", "operations", "testing"]
    for key in required:
        if not is_present(data.get(key)):
            errors.append(f"Missing required section: {key}")

    workload = data.get("workload", {})
    if isinstance(workload, dict):
        for key in ("peak_reads_per_second", "peak_writes_per_second", "estimated_records"):
            if workload.get(key) is None:
                warnings.append(f"workload.{key} is unknown; add an estimate or state why it is unavailable")
        if workload.get("p95_latency_ms") is None:
            warnings.append("workload.p95_latency_ms is not defined")
        if workload.get("p99_latency_ms") is None:
            warnings.append("workload.p99_latency_ms is not defined")

    requirements = data.get("requirements", {})
    if isinstance(requirements, dict):
        for key in ("availability_target_percent", "rpo_minutes", "rto_minutes"):
            if requirements.get(key) is None:
                warnings.append(f"requirements.{key} is not defined")

    model = data.get("data_model", {})
    if isinstance(model, dict):
        if not is_present(model.get("entities")):
            warnings.append("data_model.entities is empty")
        if not is_present(model.get("invariants")):
            warnings.append("data_model.invariants is empty; list the business rules that must always hold")
        if not is_present(model.get("source_of_truth")):
            warnings.append("data_model.source_of_truth is not identified")

    distribution = data.get("distribution", {})
    if isinstance(distribution, dict):
        if distribution.get("replication_enabled") is True:
            if not is_present(distribution.get("replication_reason")):
                warnings.append("Replication is enabled but distribution.replication_reason is missing")
            if distribution.get("max_replication_lag_ms") is None:
                warnings.append("Replication is enabled but max replication lag is not defined")
            if not is_present(distribution.get("failover_plan")):
                warnings.append("Replication is enabled but failover_plan is missing")
        if distribution.get("partitioning_enabled") is True:
            if not is_present(distribution.get("partition_key")):
                errors.append("Partitioning is enabled but partition_key is missing")
            if not is_present(distribution.get("hot_key_strategy")):
                warnings.append("Partitioning is enabled but hot_key_strategy is missing")
        if distribution.get("distributed_system") is True and not is_present(distribution.get("reason_for_distribution")):
            warnings.append("A distributed system is proposed without a documented reason")

    pipeline = data.get("pipeline", {})
    if isinstance(pipeline, dict):
        kind = pipeline.get("type", "none")
        if kind == "stream":
            if not is_present(pipeline.get("event_schema")):
                errors.append("Streaming is selected but pipeline.event_schema is missing")
            if not is_present(pipeline.get("late_event_policy")):
                warnings.append("Streaming is selected but late_event_policy is missing")
            if pipeline.get("replay_required") is True and not is_present(pipeline.get("idempotency_strategy")):
                errors.append("Replay is required but no idempotency_strategy is defined")
            if not is_present(pipeline.get("retention_days")):
                warnings.append("Streaming is selected but event retention is not defined")
        elif kind == "batch":
            if not is_present(pipeline.get("input_boundary")):
                warnings.append("Batch is selected but pipeline.input_boundary is missing")
            if not is_present(pipeline.get("retry_strategy")):
                warnings.append("Batch is selected but retry_strategy is missing")
        elif kind not in ("none", None):
            warnings.append(f"Unknown pipeline.type '{kind}'. Expected none, batch or stream")

    operations = data.get("operations", {})
    if isinstance(operations, dict):
        for key in ("backup_strategy", "restore_procedure", "monitoring_and_alerting"):
            if not is_present(operations.get(key)):
                warnings.append(f"operations.{key} is missing")

    testing = data.get("testing", {})
    if isinstance(testing, dict):
        for key in ("invariant_tests", "load_tests", "failure_recovery_tests"):
            if not is_present(testing.get(key)):
                warnings.append(f"testing.{key} is missing")

    if errors:
        print("ARCHITECTURE BRIEF: FAILED")
        for item in errors:
            print(f"ERROR: {item}")
    else:
        print("ARCHITECTURE BRIEF: STRUCTURE OK")

    for item in warnings:
        print(f"WARNING: {item}")

    print(f"Summary: {len(errors)} error(s), {len(warnings)} warning(s)")
    print("Reminder: this script checks completeness only. It does not prove architecture correctness.")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
