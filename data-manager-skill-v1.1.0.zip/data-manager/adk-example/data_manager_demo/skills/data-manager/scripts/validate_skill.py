#!/usr/bin/env python3
"""Validate the Agent Skills package structure without third-party packages."""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_NAME = "data-manager"


def fail(message: str, errors: list[str]) -> None:
    errors.append(message)


def main() -> int:
    errors: list[str] = []
    skill_file = ROOT / "SKILL.md"
    if not skill_file.is_file():
        fail("SKILL.md is missing", errors)
    else:
        content = skill_file.read_text(encoding="utf-8")
        if not content.startswith("---\n"):
            fail("SKILL.md must start with YAML frontmatter", errors)
        else:
            parts = content.split("---", 2)
            if len(parts) < 3:
                fail("Frontmatter closing delimiter is missing", errors)
            else:
                frontmatter = parts[1]
                name_match = re.search(r"^name:\s*([^\n]+)$", frontmatter, re.M)
                desc_match = re.search(r"^description:\s*(.+)$", frontmatter, re.M)
                name = name_match.group(1).strip() if name_match else ""
                description = desc_match.group(1).strip() if desc_match else ""
                if name != EXPECTED_NAME:
                    fail(f"Skill name must be '{EXPECTED_NAME}'", errors)
                if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", name):
                    fail("Skill name must use lowercase letters, numbers and single hyphens", errors)
                if not description:
                    fail("Skill description is missing", errors)
                elif len(description) > 1024:
                    fail("Skill description exceeds 1024 characters", errors)

    required_files = [
        "README.md", "SOURCES.md", "READING_AUDIT.md", "VERSION",
        "references/00-book-map.md", "references/09-design-workflow.md",
        "agents/data-architect.md", "agents/reliability-auditor.md",
        "templates/architecture-brief.md", "scripts/install_skill.py",
        "scripts/validate_architecture.py",
        "scripts/check_secrets.py",
        "agents/orchestrator.md",
    ]
    for relative in required_files:
        if not (ROOT / relative).is_file():
            fail(f"Required file missing: {relative}", errors)

    for folder in ("references", "agents", "templates", "scripts", "tests"):
        if not (ROOT / folder).is_dir():
            fail(f"Required directory missing: {folder}/", errors)

    for path in ROOT.rglob("*.py"):
        if "__pycache__" in path.parts:
            continue
        try:
            compile(path.read_text(encoding="utf-8"), str(path), "exec")
        except (SyntaxError, UnicodeDecodeError) as exc:
            fail(f"Python syntax/read error in {path.relative_to(ROOT)}: {exc}", errors)

    if errors:
        print("SKILL VALIDATION: FAILED")
        for error in errors:
            print(f"- {error}")
        return 1

    print("SKILL VALIDATION: PASSED")
    print(f"Root: {ROOT}")
    print(f"Skill: {EXPECTED_NAME}")
    print("Required files and Python syntax: OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
