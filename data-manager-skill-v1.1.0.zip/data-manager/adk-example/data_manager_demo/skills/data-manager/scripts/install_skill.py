#!/usr/bin/env python3
"""Copy data-manager into a selected agent's project skill directory."""
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

SOURCE = Path(__file__).resolve().parents[1]
SKILL_NAME = "data-manager"
TARGETS = {
    "codex": Path(".agents/skills"),
    "gemini-cli": Path(".agents/skills"),
    "antigravity": Path(".agents/skills"),
    "claude-code": Path(".claude/skills"),
    "opencode": Path(".opencode/skills"),
    "cursor": Path(".cursor/skills"),
    "adk-python": Path("skills"),
}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--agent", required=True, choices=[*TARGETS, "all"])
    parser.add_argument("--scope", choices=["project"], default="project")
    parser.add_argument("--root", required=True, type=Path, help="Root folder of the target project")
    parser.add_argument("--dry-run", action="store_true", help="Show the planned copy without writing files")
    parser.add_argument("--force", action="store_true", help="Replace an existing data-manager directory")
    args = parser.parse_args()

    root = args.root.expanduser().resolve()
    if not root.exists() or not root.is_dir():
        print(f"ERROR: project root does not exist or is not a directory: {root}", file=sys.stderr)
        return 2

    agents = list(TARGETS) if args.agent == "all" else [args.agent]
    destinations = sorted({root / TARGETS[name] / SKILL_NAME for name in agents}, key=str)
    existing = [path for path in destinations if path.exists()]
    if existing and not args.force:
        print("ERROR: an installation already exists. Use --force only after reviewing it:", file=sys.stderr)
        for path in existing:
            print(f"  {path}", file=sys.stderr)
        return 2

    for destination in destinations:
        print(f"{'WOULD INSTALL' if args.dry_run else 'INSTALLING'}: {SOURCE} -> {destination}")
        if args.dry_run:
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            shutil.rmtree(destination)
        shutil.copytree(
            SOURCE,
            destination,
            ignore=shutil.ignore_patterns("adk-example", "__pycache__", "*.pyc", ".DS_Store"),
        )

    if args.dry_run:
        print("Dry run complete. No files were changed.")
    else:
        print("Installation complete. Run the target agent and confirm that it discovers the skill.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
