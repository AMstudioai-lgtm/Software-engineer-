#!/usr/bin/env python3
"""Basic accidental-secret scanner for the skill repository."""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PATTERNS = {
    "Google API key": re.compile(r"AIza[0-9A-Za-z_-]{30,}"),
    "OpenAI-style secret": re.compile(r"sk-[A-Za-z0-9_-]{24,}"),
    "Private key block": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
}
IGNORED_PARTS = {".git", ".venv", "__pycache__"}


def main() -> int:
    findings: list[str] = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or any(part in IGNORED_PARTS for part in path.parts):
            continue
        if path.name in {".env.example", ".env.template"}:
            continue
        try:
            content = path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        for label, pattern in PATTERNS.items():
            for match in pattern.finditer(content):
                line = content.count("\n", 0, match.start()) + 1
                findings.append(f"{path.relative_to(ROOT)}:{line}: possible {label}")
    if findings:
        print("POSSIBLE SECRETS FOUND")
        for finding in findings:
            print(f"- {finding}")
        print("Review manually. This scanner can produce false positives and cannot prove the repository is secret-free.")
        return 1
    print("SECRET SCAN: no known key patterns found")
    print("This basic pattern scan is not a guarantee that no secret exists.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
