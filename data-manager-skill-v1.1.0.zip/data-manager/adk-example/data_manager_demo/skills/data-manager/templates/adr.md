# ADR-XXX : titre de la décision

- Statut : proposée | acceptée | remplacée | rejetée
- Date : YYYY-MM-DD
- Décideurs :

## Contexte
Quel problème et quelles contraintes motivent la décision ?

## Exigences déterminantes
Quelles exigences et quels invariants influencent le choix ?

## Options considérées
1. Option A : avantages, coûts, risques.
2. Option B : avantages, coûts, risques.

## Décision
Quelle option est retenue et pourquoi ?

## Conséquences
- Positives :
- Négatives :
- Risques résiduels :
- Migration / retour arrière :

## Conditions de réexamen
Quelles mesures ou évolutions déclencheront une nouvelle décision ?

## Preuves et références
- Tests / benchmarks :
- Chapitres DDIA :
- Documentation actuelle :
