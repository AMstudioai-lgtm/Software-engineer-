# Architecture brief

## 1. Contexte métier
- Produit / service :
- Utilisateurs et rôles :
- Problème à résoudre :
- Coût métier d'une panne ou d'une donnée incorrecte :

## 2. Cas d'utilisation et requêtes
| ID | Opération | Lecture/écriture | Fréquence estimée | Latence cible | Priorité |
|---|---|---|---:|---:|---|

## 3. Exigences
- Disponibilité cible :
- RPO / RTO :
- Fraîcheur attendue :
- Cohérence requise :
- Rétention :
- Sécurité / conformité :
- Budget et capacité d'exploitation :

## 4. Profil de charge
- Utilisateurs actifs :
- Requêtes/s par opération :
- Ratio lecture/écriture :
- Taille moyenne / maximale :
- Croissance par jour / mois :
- Pics / distribution des clés :

## 5. Données
- Entités :
- Relations :
- Identifiants :
- Invariants métier :
- Source de vérité :
- Vues ou index dérivés :

## 6. Options
| Option | Avantages | Coûts | Risques | Critère de rejet |
|---|---|---|---|---|

## 7. Architecture retenue
- Composants :
- Flux d'écriture :
- Flux de lecture :
- Transactions :
- Réplication / partitionnement :
- Batch / streaming :

## 8. Pannes et reprise
| Scénario | Impact | Détection | Récupération | Données perdues ? |
|---|---|---|---|---|

## 9. Validation
- Tests d'invariants :
- Tests de concurrence :
- Tests de charge :
- Tests de panne / reprise :
- Tests de migration / restauration :

## 10. Hypothèses, inconnues et approbations
- Hypothèses :
- Inconnues :
- Décisions à valider par un humain :
