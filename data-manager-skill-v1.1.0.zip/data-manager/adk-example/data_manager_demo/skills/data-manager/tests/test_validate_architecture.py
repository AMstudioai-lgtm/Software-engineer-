from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VALIDATOR = ROOT / "scripts" / "validate_architecture.py"
EXAMPLE = ROOT / "templates" / "architecture-example.json"


class ArchitectureValidatorTests(unittest.TestCase):
    def run_validator(self, payload: dict) -> subprocess.CompletedProcess[str]:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "brief.json"
            path.write_text(json.dumps(payload), encoding="utf-8")
            return subprocess.run(
                [sys.executable, str(VALIDATOR), str(path)],
                capture_output=True,
                text=True,
                check=False,
            )

    def test_example_brief_passes_without_warnings(self) -> None:
        result = subprocess.run(
            [sys.executable, str(VALIDATOR), str(EXAMPLE)],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("STRUCTURE OK", result.stdout)
        self.assertIn("0 warning(s)", result.stdout)

    def test_missing_required_section_fails(self) -> None:
        result = self.run_validator({"system_name": "incomplete"})
        self.assertEqual(result.returncode, 1)
        self.assertIn("Missing required section: workload", result.stdout)

    def test_partitioning_without_key_fails(self) -> None:
        payload = json.loads(EXAMPLE.read_text(encoding="utf-8"))
        payload["distribution"]["partitioning_enabled"] = True
        result = self.run_validator(payload)
        self.assertEqual(result.returncode, 1)
        self.assertIn("partition_key is missing", result.stdout)

    def test_stream_replay_without_idempotency_fails(self) -> None:
        payload = json.loads(EXAMPLE.read_text(encoding="utf-8"))
        payload["pipeline"] = {
            "type": "stream",
            "event_schema": {"name": "OrderCreated", "version": 1},
            "replay_required": True,
            "late_event_policy": "accept for 24 hours",
            "retention_days": 30
        }
        result = self.run_validator(payload)
        self.assertEqual(result.returncode, 1)
        self.assertIn("idempotency_strategy is defined", result.stdout)


if __name__ == "__main__":
    unittest.main()
