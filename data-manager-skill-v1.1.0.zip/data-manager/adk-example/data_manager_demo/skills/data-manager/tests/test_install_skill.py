from __future__ import annotations

import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INSTALLER = ROOT / "scripts" / "install_skill.py"


class InstallerTests(unittest.TestCase):
    def test_dry_run_does_not_create_destination(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            project = Path(tmp)
            result = subprocess.run(
                [sys.executable, str(INSTALLER), "--agent", "codex", "--root", str(project), "--dry-run"],
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertFalse((project / ".agents" / "skills" / "data-manager").exists())

    def test_install_and_overwrite_guard(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            project = Path(tmp)
            command = [sys.executable, str(INSTALLER), "--agent", "codex", "--root", str(project)]
            first = subprocess.run(command, capture_output=True, text=True, check=False)
            self.assertEqual(first.returncode, 0, first.stdout + first.stderr)
            installed = project / ".agents" / "skills" / "data-manager"
            self.assertTrue((installed / "SKILL.md").is_file())

            second = subprocess.run(command, capture_output=True, text=True, check=False)
            self.assertEqual(second.returncode, 2)
            self.assertIn("already exists", second.stderr)


if __name__ == "__main__":
    unittest.main()
