# Stockage et récupération

Source : Kleppmann, chapitre 3, pages imprimées 67–100.

## OLTP et analytique
Les charges OLTP sont généralement orientées utilisateur. Elles comportent de nombreuses requêtes qui touchent un petit nombre d'enregistrements, souvent trouvés par clé. Les accès ciblés et le coût des recherches peuvent être déterminants.

Les charges analytiques exécutent moins de requêtes, mais chacune peut lire un très grand nombre de lignes. Le débit de lecture et la quantité de données scannées deviennent importants. Le stockage en colonnes aide à ne lire que les colonnes utiles et à compresser les données.

## Deux grandes familles de moteurs OLTP
- Journaux structurés (log-structured) : écritures append-only, segments obsolètes supprimés, structures comme les SSTables et LSM-trees. Les écritures séquentielles peuvent améliorer le débit d'écriture, avec des compromis de compaction, amplification et lectures.
- Mise à jour sur place (update-in-place) : pages de taille fixe modifiées, avec les B-trees comme exemple majeur. Les compromis incluent la gestion des pages, des écritures et des index.

Aucune famille n'est automatiquement meilleure. Le bon choix dépend de la charge réelle, de la distribution des opérations, du matériel et du comportement du moteur.

## Index
Un index accélère certains accès en échange d'espace et de travail supplémentaire lors des écritures. Les index secondaires, composés et spécialisés répondent à des motifs de requête différents. Un index inutilisé reste un coût.

## Entrepôts de données
Les systèmes analytiques peuvent privilégier le stockage en colonnes, la compression et les scans séquentiels. Un index optimisé pour des recherches ponctuelles n'est pas nécessairement adapté à un scan de millions de lignes.

## Questions à poser
- Quel est le ratio lectures/écritures ?
- Les requêtes accèdent-elles à quelques lignes ou scannent-elles de larges ensembles ?
- Quelles colonnes sont lues ensemble ?
- Quelle amplification d'écriture et quelle compaction sont acceptables ?
- Quels index servent réellement les requêtes prioritaires ?

## Extension pratique
`ENGINEERING_EXTENSION`: associer chaque index proposé à une requête, à un gain attendu et à un coût d'écriture. Mesurer avec un jeu de données représentatif avant de déclarer le choix performant.
