# Modèles de données et langages de requête

Source : Kleppmann, chapitre 2, pages imprimées 25–62.

## Modèle relationnel
Les données sont représentées par des relations entre tables. Le modèle est adapté aux liens explicites, aux contraintes et aux requêtes combinant plusieurs ensembles de données. Les jointures permettent de recomposer des informations normalisées.

## Modèle document
Une donnée peut être stockée comme un document autonome, souvent proche de la structure manipulée par l'application. Ce modèle convient lorsque les données sont naturellement regroupées et que les relations entre documents restent limitées. Les relations nombreuses ou les mises à jour transversales peuvent devenir difficiles.

## Modèle graphe
Les sommets représentent des entités et les arêtes leurs relations. Il est adapté lorsque les relations sont centrales, multiples ou traversées de façon variable. Le chapitre aborde notamment les graphes de propriétés et RDF.

## Principe de choix
Aucun modèle n'est universel. Un modèle peut être simulé avec un autre, mais cette simulation peut devenir maladroite. Choisis selon les relations, les requêtes, les contraintes et les évolutions probables, pas selon une mode.

## Schéma et langage de requête
Le chapitre compare des approches déclaratives et procédurales, et plusieurs langages comme SQL, MapReduce, Cypher, SPARQL et Datalog. Le langage de requête façonne la manière dont le système exprime les opérations et les relations.

## Questions à poser
- Quelles entités et relations existent réellement ?
- Quelles requêtes sont fréquentes et lesquelles sont critiques ?
- Les données sont-elles autonomes ou fortement liées ?
- Quelles contraintes doivent être garanties au niveau du stockage ?
- Quelles jointures ou traversées seront coûteuses ?

## Extension pratique
`ENGINEERING_EXTENSION`: construire un mini-catalogue des requêtes principales et des invariants avant de sélectionner une base. Pour chaque requête, préciser les données lues, la sélectivité, le nombre de relations traversées et les écritures induites.
