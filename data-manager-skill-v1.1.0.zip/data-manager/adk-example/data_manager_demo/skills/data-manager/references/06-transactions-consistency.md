# Transactions, isolation et cohérence

Source : Kleppmann, chapitres 7 et 9, pages imprimées 213–257 et 311–363.

## Transactions
Une transaction regroupe plusieurs opérations pour que le système respecte des garanties définies. Le chapitre utilise les propriétés ACID et explique que les détails d'implémentation et les niveaux d'isolation diffèrent entre systèmes.

## Anomalies à rechercher
- Dirty read : lecture d'une écriture non validée.
- Dirty write : écrasement d'une écriture non validée.
- Non-repeatable read / read skew : le même client observe des valeurs qui changent ou un état incohérent.
- Lost update : une écriture concurrente écrase une mise à jour.
- Write skew : deux transactions lisent un état commun puis modifient des éléments distincts, violant un invariant combiné.
- Phantom : une requête répétée observe un ensemble de lignes différent.

Le livre examine read committed, snapshot isolation et serializability. Les mécanismes abordés incluent MVCC, exécution sérialisée, verrouillage à deux phases et serializable snapshot isolation.

## Cohérence distribuée
Distingue notamment la linéarisabilité, qui donne l'illusion d'un ordre global respectant les temps réels, de la cohérence causale, qui préserve les relations de cause à effet sans imposer nécessairement un ordre total global.

Le choix dépend des invariants métier. Une contrainte de solde, stock, réservation ou unicité ne se traite pas comme une simple donnée de cache.

## Questions à poser
- Quels invariants doivent rester vrais sous concurrence ?
- Quelles opérations doivent être atomiques ensemble ?
- Quel niveau d'isolation protège chaque invariant ?
- Où sont les points de lecture/écriture concurrents ?
- Une vue éventuellement cohérente est-elle acceptable pour cet écran ou cette décision ?

## Extension pratique
`ENGINEERING_EXTENSION`: écris les invariants sous forme de règles testables, puis crée des tests concurrents qui tentent de les violer. Ne choisis pas un niveau d'isolation uniquement parce qu'il est le défaut du moteur.
