# Encodage et évolution des données

Source : Kleppmann, chapitre 4, pages imprimées 107–135.

## Encodage
Les structures en mémoire doivent être converties en octets pour être stockées ou transmises. Le chapitre compare des formats textuels tels que JSON, XML et CSV à des formats binaires et à des formats associés à des schémas, dont Protocol Buffers et Avro.

Le choix influe sur la taille, le coût de traitement, la compatibilité et l'architecture des services. Il faut considérer les lecteurs et écrivains existants, pas seulement le code qui produit le format aujourd'hui.

## Compatibilité
- Compatibilité ascendante (backward): une version récente du code peut lire les données écrites par une ancienne version.
- Compatibilité descendante (forward): une ancienne version du code peut lire les données écrites par une version plus récente, dans les limites du format.

Les déploiements progressifs créent une période où plusieurs versions coexistent. Le stockage persistant peut conserver des données écrites par de nombreuses versions précédentes.

## Évolution de schéma
Un changement de schéma doit préciser les nouveaux champs, les valeurs par défaut, le traitement des champs inconnus, les transformations nécessaires et la manière de revenir en arrière. La compatibilité des formats ne garantit pas à elle seule la compatibilité du sens métier.

## Flux de données entre composants
Le chapitre traite de l'échange via bases de données, appels de service et messages. Dans chaque cas, il faut identifier qui écrit, qui lit, combien de temps les données survivent et quelles versions peuvent se rencontrer.

## Questions à poser
- Qui lit les données et avec quelle version ?
- Quel est le cycle de vie d'un enregistrement ancien ?
- Le déploiement est-il progressif ?
- Comment une migration est-elle reprise ou annulée ?
- Les champs inconnus et les valeurs manquantes ont-ils un sens défini ?

## Extension pratique
`ENGINEERING_EXTENSION`: toute modification de format ou schéma en production doit inclure un plan expand/contract, des tests de compatibilité, une stratégie de backfill et une restauration testée.
