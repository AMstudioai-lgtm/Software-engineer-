# Réplication et partitionnement

Source : Kleppmann, chapitres 5 et 6, pages imprimées 145–208.

## Réplication
La réplication conserve des copies des mêmes données sur plusieurs nœuds. Les motivations incluent la disponibilité, la tolérance aux pannes, la capacité de lecture et la proximité géographique.

Le livre examine trois familles :
- Leader/follower : un leader reçoit les écritures et les réplicas suivent son journal.
- Multi-leader : plusieurs nœuds acceptent des écritures. Les conflits et leur résolution deviennent essentiels.
- Leaderless : les clients écrivent et lisent auprès de plusieurs réplicas selon un protocole de quorum ou de réparation.

Il distingue réplication synchrone et asynchrone. Une réplication asynchrone réduit l'attente mais expose à un retard de réplication et à la perte potentielle de certaines écritures confirmées lors d'une panne du leader, selon les garanties du système.

Les garanties observables peuvent inclure read-your-writes, monotonic reads et consistent prefix reads. Décris explicitement ce qu'un utilisateur est autorisé à observer.

## Partitionnement
Le partitionnement répartit les données entre plusieurs groupes de nœuds. Il peut être fondé sur une plage de clés ou sur un hachage.

- Plages : peuvent faciliter les scans de plage, mais des clés mal distribuées créent des hotspots.
- Hachage : répartit souvent mieux les clés, mais complique les scans ordonnés et certains accès par plage.

Le rééquilibrage déplace des partitions lorsque le nombre de nœuds ou la charge change. Les index secondaires peuvent être locaux à une partition ou globaux, avec des compromis de routage et de coordination.

## Questions à poser
- Pourquoi faut-il répliquer ou partitionner ?
- Quel est le retard de réplication acceptable ?
- Comment gérer les conflits d'écriture ?
- La clé de partition distribue-t-elle bien les accès et les données ?
- Une requête doit-elle contacter toutes les partitions ?
- Comment rééquilibrer sans interrompre le service ?

## Extension pratique
`ENGINEERING_EXTENSION`: refuse une clé de partition sans analyse de distribution. Documente le comportement des clés chaudes, le coût des requêtes multi-partitions, les procédures de failover et les limites de cohérence.
