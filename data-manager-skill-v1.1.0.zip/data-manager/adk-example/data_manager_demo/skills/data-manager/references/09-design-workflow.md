# Méthode de conception utilisable par une équipe

Cette méthode convertit les principes des chapitres 1 à 11 en artefacts pratiques. Les étapes et modèles ci-dessous sont des extensions d'ingénierie (`ENGINEERING_EXTENSION`), pas une méthode prescrite mot pour mot par le livre.

## 1. Recueillir
Rédiger les cas d'utilisation, le modèle de permission, les entités, les requêtes, les invariants et les exigences de conformité. Séparer les faits des hypothèses.

## 2. Mesurer
Construire un profil de charge :
- requêtes par seconde par catégorie ;
- distribution lecture/écriture ;
- taille moyenne et maximale des enregistrements ;
- croissance et rétention ;
- cardinalité et distribution des clés ;
- pics, concurrence, latence cible ;
- fraîcheur et cohérence par type de requête.

## 3. Comparer
Comparer au moins deux options réellement plausibles. Par exemple : une base relationnelle unique vs relationnelle avec réplication, ou transactionnel + entrepôt analytique. Écarter explicitement les solutions qui ajoutent une complexité non justifiée.

## 4. Modéliser
Lister les entités, relations, contraintes, identifiants, cardinalités, opérations critiques et propriétaires de la vérité. Dessiner les flux d'écriture et de lecture.

## 5. Définir les garanties
Pour chaque invariant, préciser la transaction ou le protocole qui le protège. Pour chaque vue secondaire, préciser son retard maximal et les effets d'une donnée périmée.

## 6. Décrire les pannes
Au minimum : indisponibilité de base, perte de connectivité, retard de réplication, duplication de messages, consommateur arrêté, migration interrompue, restauration et surcharge.

## 7. Vérifier
Préparer des tests de concurrence, charge, latence, panne, redémarrage, reprise, compatibilité, migration et restauration. Utiliser des volumes et distributions de données réalistes.

## 8. Décider
Écrire un ADR avec le contexte, la décision, les options, les conséquences et les conditions de réexamen. Consigner les coûts d'exploitation.

## 9. Valider
Faire vérifier les garanties par un humain responsable. Le validateur de ce skill ne remplace pas un test de charge, un audit de sécurité, ni une revue de production.
