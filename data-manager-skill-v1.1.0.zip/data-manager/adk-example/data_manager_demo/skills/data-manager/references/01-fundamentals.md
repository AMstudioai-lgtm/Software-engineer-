# Fondations : fiabilité, charge et maintenabilité

Source : Kleppmann, chapitre 1, pages imprimées 1–20.

## 1. Exigences fonctionnelles et non fonctionnelles
Les exigences fonctionnelles disent ce que le système fait : enregistrer, lire, rechercher ou transformer des données. Les exigences non fonctionnelles définissent les qualités attendues : fiabilité, scalabilité, sécurité, conformité, compatibilité et maintenabilité.

## 2. Fiabilité
La fiabilité signifie que le système continue à fonctionner correctement malgré des fautes. Le chapitre distingue notamment :
- Fautes matérielles, souvent aléatoires et relativement indépendantes.
- Fautes logicielles, souvent systématiques et difficiles à éliminer.
- Erreurs humaines, qui doivent être anticipées par des garde-fous et des procédures.

Une faute n'entraîne pas nécessairement une défaillance visible si le système la tolère. Pour chaque composant critique, identifie la faute, son effet, sa détection et la récupération.

## 3. Scalabilité
La scalabilité n'est pas un nombre magique d'utilisateurs. Décris une charge avec des mesures adaptées :
- nombre et type de requêtes par seconde ;
- ratio lectures/écritures ;
- nombre d'objets touchés par requête ;
- taille des objets et données conservées ;
- distribution des clés et pics de trafic.

Mesure la latence en percentiles, notamment p50, p95 et p99. Une moyenne peut masquer une mauvaise expérience pour une partie des utilisateurs. Une stratégie d'augmentation de capacité doit être liée au profil de charge observé.

## 4. Maintenabilité
Le chapitre souligne trois dimensions pratiques :
- Opérabilité : rendre le système visible et administrable.
- Simplicité : contrôler la complexité et les abstractions.
- Évolutivité : faciliter les changements futurs.

## Questions à poser
1. Quelle panne ou erreur humaine est la plus probable ?
2. Quelle métrique se dégrade lorsque la charge augmente ?
3. Quel niveau de latence est acceptable pour les opérations critiques ?
4. Qui exploitera le système et comment détectera-t-il un incident ?

## Traduction pratique du skill
`ENGINEERING_EXTENSION`: ne propose pas de solution haute disponibilité ou distribuée avant d'avoir une exigence mesurable. Commence par une cible de service et un profil de charge. Référence : chapitre 1.
