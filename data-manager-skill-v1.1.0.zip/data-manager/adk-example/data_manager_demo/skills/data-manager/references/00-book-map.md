# Carte du livre

Source : Martin Kleppmann, *Designing Data-Intensive Applications* (2017).

| Partie | Chapitres | Sujet |
|---|---:|---|
| I. Foundations of Data Systems | 1–4 | Fiabilité, scalabilité, maintenabilité, modèles de données, stockage, évolution |
| II. Distributed Data | 5–9 | Réplication, partitionnement, transactions, pannes distribuées, cohérence et consensus |
| III. Derived Data | 10–11 | Traitement batch et traitement de flux |

## Chapitres

1. Reliable, Scalable and Maintainable Applications, pages imprimées 1–20.
2. Data Models and Query Languages, pages 25–62.
3. Storage and Retrieval, pages 67–100.
4. Encoding and Evolution, pages 107–135.
5. Replication, pages 145–186.
6. Partitioning, pages 191–208.
7. Transactions, pages 213–257.
8. The Trouble with Distributed Systems, pages 265–302.
9. Consistency and Consensus, pages 311–363.
10. Batch Processing, pages 377–416.
11. Stream Processing, pages 425–462.

## Guide rapide

- Besoins et objectifs de service : chap. 1.
- Relations, documents, graphes et langage de requête : chap. 2.
- Index, OLTP, analytics, B-tree, LSM et colonnes : chap. 3.
- Formats, schémas, compatibilité et déploiements progressifs : chap. 4.
- Réplicas, leaders, retards et conflits : chap. 5.
- Clés de partition, hotspots et rééquilibrage : chap. 6.
- Isolation, anomalies, MVCC et sérialisabilité : chap. 7.
- Réseau, horloges, timeout et pannes partielles : chap. 8.
- Linéarisabilité, causalité, consensus et ordre : chap. 9.
- Traitement borné, MapReduce et jointures : chap. 10.
- Événements, brokers, CDC, event sourcing, temps et replay : chap. 11.
