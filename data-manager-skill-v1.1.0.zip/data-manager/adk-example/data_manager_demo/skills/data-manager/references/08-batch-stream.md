# Batch processing et stream processing

Source : Kleppmann, chapitres 10 et 11, pages imprimées 377–462.

## Batch
Le batch traite une entrée bornée puis produit un résultat fini. Le chapitre présente l'esprit des outils Unix et de MapReduce : entrées immuables, petits opérateurs composables, sorties réutilisables. Le partitionnement rassemble les enregistrements pertinents. La tolérance aux pannes repose souvent sur la reprise de tâches et la possibilité de recalculer.

Le chapitre examine notamment les jointures sort-merge, broadcast hash join et partitioned hash join. Ces formes dépendent de la taille relative des jeux de données et de la distribution des clés.

## Streaming
Le streaming traite un flux non borné d'événements. Les brokers de messages classiques peuvent répartir des messages entre consommateurs et les supprimer après acquittement. Les brokers fondés sur un journal conservent les événements et suivent la progression par offset, ce qui autorise le replay.

Les sources peuvent être des événements utilisateur, capteurs, flux externes ou changements d'une base de données. Le change data capture (CDC) capture les modifications d'un stockage. Event sourcing enregistre les événements métier comme source de vérité. Ces approches sont proches mais ne sont pas identiques.

## Données dérivées
Un flux de changements peut alimenter des caches, index de recherche, vues matérialisées et systèmes analytiques. La reconstruction à partir d'un historique exige une stratégie de replay et une gestion du temps.

## Temps et doublons
Distingue event time (moment de l'événement dans le monde métier) et processing time (moment où le système le traite). Les événements tardifs peuvent arriver après la clôture d'une fenêtre. Les retries et redélivraisons peuvent produire des doublons.

L'expression « exactly once » doit être limitée à sa frontière réelle. La livraison d'un message, la mise à jour d'un état interne et un effet externe ne bénéficient pas automatiquement de la même garantie. Idempotence, transactions et déduplication restent essentielles.

## Questions à poser
- L'entrée est-elle bornée ou continue ?
- Faut-il relire les événements anciens ?
- Quel ordre est requis par clé ou globalement ?
- Combien de retard accepte-t-on ?
- Comment les consommateurs reprennent-ils après panne ?
- Les effets externes sont-ils idempotents ?

## Extension pratique
`ENGINEERING_EXTENSION`: exige une politique de rétention, un format d'événement versionné, un comportement pour les événements tardifs, une stratégie de replay, une clé de déduplication et un plan de reconstruction des vues dérivées.
