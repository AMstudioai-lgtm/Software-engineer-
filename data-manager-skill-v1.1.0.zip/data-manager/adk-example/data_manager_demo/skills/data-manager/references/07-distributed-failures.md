# Pannes distribuées, temps et consensus

Source : Kleppmann, chapitres 8 et 9, pages imprimées 265–363.

## Pannes partielles
Dans un système distribué, une partie du système peut être lente, inaccessible ou en panne alors que le reste continue. Un timeout ne permet pas toujours de distinguer un processus arrêté, un réseau lent ou un nœud surchargé.

Le système ne dispose pas automatiquement d'une mémoire partagée globale ni d'une horloge parfaite. Les retards réseau, les pauses de processus et les différences d'horloge compliquent les décisions.

## Modèles de panne et garanties
Sépare :
- Safety : quelque chose de mauvais n'arrive jamais, par exemple deux leaders ne valident pas des décisions incompatibles.
- Liveness : quelque chose de bon finit par arriver, par exemple le système progresse sous des hypothèses données.

Une conception doit annoncer ses hypothèses sur les fautes et ses comportements lorsque ces hypothèses ne tiennent plus.

## Consensus et ordre
Le chapitre explore la linéarisabilité, les relations causales, l'ordre total, le consensus, l'atomic commit, les leases et les mécanismes de coordination. Ces notions servent à coordonner les décisions entre nœuds, mais elles ont un coût de latence et de disponibilité selon les conditions.

## Quand ne pas distribuer
Le livre rappelle qu'une machine unique peut déjà faire beaucoup. Si les exigences de capacité, de disponibilité ou de proximité géographique ne justifient pas la distribution, la simplicité d'un système non distribué est souvent préférable.

## Questions à poser
- Quel comportement suit un timeout ambigu ?
- Que se passe-t-il en cas de partition réseau ?
- Comment éviter deux leaders actifs ?
- Quels événements exigent un ordre global, causal ou aucun ordre particulier ?
- Le besoin justifie-t-il les coûts de coordination ?

## Extension pratique
`ENGINEERING_EXTENSION`: documente les hypothèses de panne, timeouts, retries, budgets de latence, circuit breakers, limites de concurrence et procédures de récupération. Un retry doit être sûr ou protégé par une clé d'idempotence.
