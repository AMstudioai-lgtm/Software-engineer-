# data-manager

Skill multi-agents pour concevoir et auditer des systèmes de données. Il transforme les concepts de *Designing Data-Intensive Applications* (Martin Kleppmann, 2017) en procédures d'analyse, de décision et de validation.

## Contenu

- `SKILL.md`: instructions principales et contrat de sortie.
- `references/`: fiches de connaissances, résumées et reformulées.
- `agents/`: six rôles spécialisés, utilisables par un orchestrateur multi-agents.
- `templates/`: brief d'architecture, ADR et profil de charge.
- `scripts/`: installation, validation du skill et contrôle de complétude d'un brief JSON.
- `tests/`: tests unitaires du validateur.
- `adk-example/`: exemple d'intégration avec Google ADK Python.
- `READING_AUDIT.md`: méthode de lecture et limites de l'audit.

## Installation rapide

Depuis le dossier extrait :

```bash
python scripts/validate_skill.py
python -m unittest discover -s tests -v
python scripts/install_skill.py --agent codex --scope project --root /chemin/vers/votre-projet --dry-run
```

Retirez `--dry-run` pour copier le skill. L'installateur refuse d'écraser une installation existante sans `--force`.

Exemples d'agents pris en charge par l'installateur : `codex`, `gemini-cli`, `antigravity`, `claude-code`, `opencode`, `cursor`, `adk-python`. Les emplacements suivent les conventions de chaque outil et peuvent évoluer. Vérifiez la documentation de votre environnement.

Pour ADK Python, donnez à `--root` le dossier qui contient le fichier `agent.py` :

```bash
python scripts/install_skill.py --agent adk-python --scope project --root /chemin/vers/votre/agent_package
```

## Google ADK Python

L'exemple ADK est autonome dans `adk-example/`. Le skill est déjà inclus dans `data_manager_demo/skills/data-manager/`.

```bash
cd adk-example
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export GOOGLE_API_KEY="votre-cle-api"
adk run data_manager_demo
```

Vous pouvez remplacer le modèle avec `ADK_MODEL`. Pour l'interface web locale, lancez `adk web --port 8000`.

L'API Skills d'ADK est expérimentale. La documentation actuelle indique la prise en charge de Google ADK Python à partir de v1.25.0. Vérifiez la version de `google-adk` et la documentation avant de l'adopter en production.

## Usage recommandé

Commencez avec un cas d'utilisation modeste. Donnez à l'agent les requêtes, volumes, invariants et objectifs de service connus. Laissez-le produire un brief avant de lui demander une technologie. Faites relire la proposition par les spécialistes utiles, puis exécutez les tests avec des données représentatives.

## Limites

Les scripts contrôlent la structure et la complétude des livrables. Ils ne prouvent ni la correction d'une architecture, ni les performances d'une base, ni la conformité réglementaire. La revue humaine reste obligatoire pour les migrations et les opérations de production.
