"""Google ADK Data Manager demo agent package."""
