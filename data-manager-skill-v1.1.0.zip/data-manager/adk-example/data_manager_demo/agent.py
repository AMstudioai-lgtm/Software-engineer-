from __future__ import annotations

import os
from pathlib import Path

from google.adk import Agent
from google.adk.skills import load_skill_from_dir
from google.adk.tools import skill_toolset

MODEL = os.getenv("ADK_MODEL", "gemini-flash-latest")
SKILL_DIR = Path(__file__).resolve().parent / "skills" / "data-manager"


def make_skill_tools() -> skill_toolset.SkillToolset:
    """Build a SkillToolset for one agent from the local skill folder."""
    skill = load_skill_from_dir(SKILL_DIR)
    return skill_toolset.SkillToolset(skills=[skill])


def make_specialist(name: str, description: str, instruction: str) -> Agent:
    return Agent(
        name=name,
        model=MODEL,
        description=description,
        instruction=instruction,
        tools=[make_skill_tools()],
    )


data_architect = make_specialist(
    name="data_architect",
    description="Conçoit l'architecture globale et compare les options de systèmes de données.",
    instruction=(
        "Tu es l'architecte des systèmes de données. Pars des besoins métier, du profil de charge, "
        "des garanties et des contraintes. Compare les options plausibles, choisis l'architecture "
        "la plus simple qui respecte les exigences et expose les compromis. Marque les hypothèses "
        "et inconnues. Utilise le skill data-manager et cite les chapitres pertinents."
    ),
)


data_modeler = make_specialist(
    name="data_modeler",
    description="Conçoit entités, relations, invariants et requêtes de données.",
    instruction=(
        "Tu es le spécialiste du modèle de données. Analyse le brief fourni. "
        "Distingue les faits, hypothèses et inconnues. Utilise le skill data-manager. "
        "Retourne entités, relations, invariants, catalogue de requêtes, options de modèle, "
        "risques et références aux chapitres pertinents. Ne choisis pas une base sans preuve."
    ),
)

storage_engineer = make_specialist(
    name="storage_engineer",
    description="Évalue stockage, index, accès OLTP et analytique.",
    instruction=(
        "Tu es le spécialiste stockage et récupération. Relie les accès aux structures "
        "de stockage et index. Compare les compromis lecture/écriture. Propose des benchmarks "
        "et indique les inconnues. Utilise le skill data-manager."
    ),
)

distributed_reviewer = make_specialist(
    name="distributed_reviewer",
    description="Examine réplication, partitionnement, cohérence et pannes distribuées.",
    instruction=(
        "Tu es le réviseur systèmes distribués. Vérifie si la distribution est justifiée. "
        "Analyse retards, conflits, hotspots, timeouts, failover et reprise. "
        "Distingue les garanties de cohérence. Utilise le skill data-manager."
    ),
)

pipeline_engineer = make_specialist(
    name="pipeline_engineer",
    description="Conçoit pipelines batch, streaming, CDC et données dérivées.",
    instruction=(
        "Tu es le spécialiste des pipelines. Distingue entrée bornée et flux non borné. "
        "Décris temps d'événement, événements tardifs, replay, duplication, idempotence "
        "et effets secondaires. Utilise le skill data-manager."
    ),
)

reliability_auditor = make_specialist(
    name="reliability_auditor",
    description="Audite les risques, tests, sauvegardes et plans de reprise.",
    instruction=(
        "Tu es l'auditeur indépendant. Cherche les façons dont la solution échoue. "
        "Vérifie invariants, sauvegardes, restauration, observabilité et tests. "
        "Retourne APPROVE, REVISE ou BLOCK avec preuves et points non testés. "
        "N'approuve pas une hypothèse non vérifiée. Utilise le skill data-manager."
    ),
)

root_agent = Agent(
    name="data_manager_coordinator",
    model=MODEL,
    description="Coordonne une équipe d'agents spécialisés en architecture des données.",
    instruction=(
        "Tu es le coordinateur Data Manager. Commence par cadrer le problème, les exigences, "
        "les volumes et les invariants. N'invente pas les informations absentes. "
        "Délègue uniquement aux spécialistes nécessaires : data_architect pour les options "
        "d'architecture, data_modeler pour les entités et "
        "invariants, storage_engineer pour les accès et index, distributed_reviewer pour la "
        "distribution, pipeline_engineer pour batch/stream, reliability_auditor pour une revue "
        "contradictoire. Fournis à chacun le même brief. Réconcilie explicitement les désaccords. "
        "Préfère la solution la plus simple qui répond aux exigences. Termine par un brief "
        "d'architecture, les compromis, les risques, le plan de validation et les décisions "
        "qui nécessitent un humain. N'exécute aucune opération destructive. Utilise le skill data-manager."
    ),
    tools=[make_skill_tools()],
    sub_agents=[
        data_architect,
        data_modeler,
        storage_engineer,
        distributed_reviewer,
        pipeline_engineer,
        reliability_auditor,
    ],
)
