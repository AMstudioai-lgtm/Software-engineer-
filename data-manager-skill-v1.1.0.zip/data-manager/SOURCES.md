# Sources et provenance

## Source principale
Martin Kleppmann. *Designing Data-Intensive Applications: The Big Ideas Behind Reliable, Scalable, and Maintainable Systems*. O'Reilly Media, 2017. ISBN 978-1-449-37332-0. Source de la synthèse des concepts dans `references/`.

## Documentation d'intégration
- Agent Skills specification: https://agentskills.io/specification
- Google ADK Skills for Agents: https://adk.dev/skills/
- Google ADK Multi-Agent Systems: https://adk.dev/tutorials/agent-team/

Les pages de documentation évoluent. Vérifier les versions et recommandations au moment de l'installation.
