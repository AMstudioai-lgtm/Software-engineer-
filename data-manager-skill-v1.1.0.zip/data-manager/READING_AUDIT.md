# Reading audit

## Source
Martin Kleppmann, *Designing Data-Intensive Applications: The Big Ideas Behind Reliable, Scalable, and Maintainable Systems*, O'Reilly Media, 2017. PDF fourni dans cette conversation, 491 pages physiques.

## Méthode réellement effectuée
Le document a été parcouru en trois passes analytiques distinctes :

1. Cartographie : extraction du texte, identification de la table des matières, de l'organisation en trois parties et des onze chapitres.
2. Analyse : extraction et examen des synthèses de fin de chapitre, repérage des concepts, garanties, cas d'usage, limites et compromis.
3. Transformation : vérification de la structure paginée rendue, puis conversion des notions en fiches de référence, procédures, contrats d'agents et contrôles exécutables.

Les 491 pages physiques ont été rendues en images et examinées par planches de contact pour vérifier que le PDF était lisible et que les pages étaient présentes.

Cette méthode ne signifie pas trois relectures littérales, mot à mot, de chaque ligne du livre. Elle signifie trois passes de travail différentes sur le texte complet extrait et la structure visuelle du PDF. Le skill ne prétend pas remplacer la lecture intégrale par un humain.

## Couverture
- Chapitres 1 à 4 : fondations, exigences, modèles, stockage et évolution.
- Chapitres 5 à 9 : réplication, partitionnement, transactions, pannes et consensus.
- Chapitres 10 à 11 : batch et streaming.

## Règles de fidélité
- Les fiches sont des synthèses originales et reformulées.
- Les références pointent vers les chapitres et pages imprimées du livre.
- Les procédures d'usage multi-agents et les scripts sont des extensions d'ingénierie, pas des affirmations attribuées à Kleppmann.
- Les produits et leurs versions doivent être vérifiés dans une documentation actuelle.
